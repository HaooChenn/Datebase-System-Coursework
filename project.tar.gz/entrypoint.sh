#!/bin/bash

node hello.js